public class Dog extends Animal{
  
  public Dog(String name, int age, String breed){
    super(name, age,breed);
  }
  
  public Dog(){}
  
  public String sound(){
   return ("Woof Woof");
  }
  
  public String toString(){
   return super.toString() + "\t"+sound()+"\t";
  }
  
  public static void main(String [] args){
   Animal a = new Dog("Dogie", 6,"Doberman");
   System.out.println("The dog is : " + a);
   System.out.print("The sound of the dog is:");
   a.sound();
  }
  
}