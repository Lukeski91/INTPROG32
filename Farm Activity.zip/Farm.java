public class Farm{
 Animal [] farm;
 int count;
 
 public Farm(int size){
  farm = new Animal[size];
  count = 0;
 }
 
 public Farm(){
  this(50);
 }
 
 public String toString(){
  StringBuffer sb = new StringBuffer();
  for(int i = 0; i < count; i++)
   sb.append(farm[i] +"\n");
  return sb.toString();
 }
 
 public void add(Animal a){
  farm[count++] = a;
 }
 
 public static void main(String [] args){
  Farm farm = new Farm();
  farm.add(new Cow("Maria",20,"Bisaya"));
  farm.add(new Cow("Cowie",10,"Brahman"));
  farm.add(new Cat("Felix",7,"Ragdoll"));  
  farm.add(new Cat("Catie",5,"Munchkin"));
  farm.add(new Dog("Oreo",4,"Shih-Tzu"));
  farm.add(new Dog("Dogie",6,"Doberman"));
  System.out.println("Name:\tBreed:\tAge:\tSound:");
  System.out.println(farm);
  
 }
}