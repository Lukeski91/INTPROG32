public abstract class Animal{
 private String name;
 private int age;
 private String breed;
 
 //constructors
 public Animal(String name, String breed,int age){
  this.name = name;
  this.breed = breed;
  this.age = age;
 }
 
 public Animal(){}

 //setters
 public void setName(String name){
  if(name != null)
   this.name = name;
 }
 
 public void setAge(int age){
  if(age <= 50)
   this.age = age;
 }
 
 public void setBreed(String breed){
  this.breed = breed;
 }
 
 //getters
 public String getName(){
  return name;
 }
 
 public String getBreed(){
  return breed;
 }
 
 public int getAge(){
  return age;
 }
 
 public abstract String sound();
 
 //toString()
 public String toString(){
  return "Name:   "+getName() + "\nBreed:   " + getBreed() + "\nAge:   " + getAge() + " \n";
 }
}